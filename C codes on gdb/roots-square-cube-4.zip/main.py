i=int(input())
num=int(input())
if i==2:
    res=num**0.5
elif i==3:
    res=num**0.333
elif i==4:
    res=num**0.25
print(res)
