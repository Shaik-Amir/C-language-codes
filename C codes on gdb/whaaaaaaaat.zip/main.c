/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
    printf("Hello World");
 printf("dfgh");
  int n,i,a,j,k,l=0,dc=0;
 int m=0;
  //scanf("%d",&a);
 a=10;
  for(i=0;i<a;i++)
  {
     if ((n*(1/k))==1)
    dc++;
  }
    printf("     %d..",dc);
    return 0;
}
