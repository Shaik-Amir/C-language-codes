#include<stdio.h>
#include<stdlib.h>
#include<math.h>
main(){
int dreq[20],cpos,i,TAD,n;
system("clear");
printf("\nEnter the number of disk reqs:\t");
scanf("%d",&n);
printf("\nReading disk requests\n");
for(i=0;i<n;i++){
printf("\nEnter disk req[%d]:\t",i+1);
scanf("%d",&dreq[i]);
}
printf("\nEnter current position of disk Read Write Head: \n");
scanf("%d",&cpos);
TAD=0;
for(i=0;i<n;i++){
printf("%d - ",cpos);
TAD=TAD+abs(dreq[i]-cpos);
cpos=dreq[i];
}
printf(" %d\n",cpos);
printf("\nTotal Disk arm movement to serve all requests = %d\n",TAD);
}
