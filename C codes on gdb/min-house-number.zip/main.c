/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,t,i,min;
    printf("input the test cases: ");
    scanf("%d",&t);
    printf("Input the number of houses; "); 
    scanf("%d",&n);
    int a[n];
    for (i=0;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    min=100;
    for (i=0; i<=n;i++)
    {
        if (a[i]<min)
        min=a[i];
    }
    printf("%d",min);
    return 0;
}
