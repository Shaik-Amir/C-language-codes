#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n[15],num=0,i=0;
    long int count=0;
    cin>>num;
    for(i=1;i<=num;i++)
    cin>>n[i];
    for(i=1;i<=num;i++)
    {
    if(n[i]<10 && n[i]>0)
        count=(1*n[i]);
    else if(n[i]<100 && n[i]>9)
        count=(1*9)+(2*(n[i]-9));
    else if(n[i]<1000 && n[i]>99)
        count=(1*9)+(2*90)+(3*(n[i]-99));
    else if(n[i]<10000 && n[i]>999)
        count=(1*9)+(2*90)+(3*900)+(4*(n[i]-999));
    cout<<count<<endl;
    }
}