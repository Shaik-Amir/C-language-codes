'''
lis=["acukdk","ih","shl","u"]
#print(len(lis[0]))
for i in len(lis.split()):
    lis2=[len(lis[0]),len(lis[1]),len(lis[2]),len(lis[3])]
    print(max(lis2))

txt = input()
spltxt=txt.split()
for i in range(int(len(spltxt))):
    lis2=[len(txt[i])]
    print(max(lis2))
    break
        '''
        
txt=input()
spltxt=[txt.split()]
print(spltxt)
lenlist=[]

for i in spltxt:
    lenlist.append(len(spltxt[i]))
    
print(lenlist)

