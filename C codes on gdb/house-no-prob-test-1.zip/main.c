#include <stdio.h>
int main()
{
    int n,a[30],b,count=0,r=0,c1,c2,i=0;
    printf("Input the number of houses,n: "); 
    scanf("%d",&n);
    for(i=0;i<=n;i++)
    {
        a[i]=i+1;
    }
    for(i=0;i<n;i++)
    {
        printf("%d ",a[i]);
    }

    return 0;
}
