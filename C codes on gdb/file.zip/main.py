open ("file1","r+")
file1=input("enter filename: ")
with open (file1) as f:
    content=f.read()
print(content)
def charcount(content,char):
    count=0
    for c in content:
     if c==char:
      count+=1 
    return count
    
for char in content:
    percentage=100*(charcount(content,char)/len(content))
    print("{0} - {1}%".format(char,round(percentage,3)))