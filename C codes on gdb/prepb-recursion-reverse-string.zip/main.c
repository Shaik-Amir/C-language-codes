#include <stdio.h>
char * reverseStringr(char [],int ,int ,int );

int main()
{
  int i,n;
  char *p;
  scanf("%d",&n);
  char a[n];
  for(i=0;i<n;i++)
  {
    scanf("%c",&a[i]);
  }
  p=reverseStringr(a,n,0,n-1);
  for(i=0;i<n;i++)
  {
    printf("\nfinal--%c",p[i]);
  }
  return 0;
}

char * reverseStringr(char a[],int n,int start,int end)
{
   int mid,j,cur;
   char temp;
   mid=n/2;
   printf("\n%d --startt",start);
   printf("\n%d --endd",end);
   if (start==end)
      return a;
  temp=a[start];
  a[start]=a[end];
  a[end]=temp;
  printf("swapped");

  reverseStringr(a,n,start+1,end-1);
}