import string
lbs=int(input())
bs=input()
nqueries=int(input())
for x in range(nqueries):
   lb=int(input())
   ub=int(input())
   #print(len(bs))
   zc=0
   oc=0
   for i in range(lb-1,ub):#seeeeeeeeeeeeee 
      #print(bs[i])
      if (bs[i]=='1'):
         oc=oc+1
      if (bs[i]=='0'):
         zc=zc+1
   print(oc-zc)