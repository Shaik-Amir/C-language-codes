/*Stack using Single Linked List*/
#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};
typedef struct node NODE;

struct Stack
{
    NODE *top;
};
typedef struct Stack STACK;

STACK *CreateStack()
{
    STACK *s;
    s=(STACK*)malloc(sizeof(STACK));
    s->top=NULL;
    return(s);
}

int isStackEmpty(STACK *s)
{
    if(s==NULL) return 0;
    if(s->top==NULL) return 0;
    return 1;
}

void push(STACK *s,int element)
{
    NODE *newNode;
    newNode=(NODE*)malloc(sizeof(NODE));
    newNode->data=element;
    newNode->next=s->top;
    s->top=newNode;
}

int pop(STACK *s)
{
    NODE *cur;
    int result;
    if(isStackEmpty(s)) return 0;
    cur=s->top;
    s->top=cur->next;
    result=cur->data;
    free(cur);
    return(result);
}

int getTop(STACK *s)
{
    if(isStackEmpty(s)) return 0;
    return(s->top->data);
}

void DestroyStack(STACK *s)
{
    if(s==NULL) return;
    while(s->top!=NULL) pop(s);
    free(s);
}

void DisplayStack(STACK *s)
{
    NODE *cur;
    if(isStackEmpty(s)) return;
    cur=s->top;
    while(cur->next!=NULL)
    {
        printf("%d\n",cur->data);
        cur=cur->next;
    }
    printf("\n");
}

int main()
{
    int top;
    STACK*s;
    int choice,e;
    
    printf("\n");
    printf("This Stack uses Single Linked List\n");
    
    while(1)
    {
        printf("\n\n");
        printf("MENU\n");
        printf("----\n");
        printf("1. Push\n");
        printf("2. Pop\n");
        printf("3. GetTop\n");
        printf("4. Print The entire Elements and Top Value\n");
        printf("0. Exit\n");
        printf("Enter Your Choice :: ");
        scanf("%d",&choice);
        if(choice==0) break;
        switch(choice)
        {
            case 1:
                    printf("Enter the Elements to be Pushed :: ");
                    scanf("%d",&e);
                     push(s,e);
                     break;
            case 2:
                    if(isStackEmpty(s))
                        printf("Stack is Empty. Can not Pop!");
                    else
                        printf("Popped ELement is %d",pop(s));
                        break;
            case 3:
                    if(isStackEmpty(s))
                        printf("Stack is Empty. Can Not Get Top Element!");
                    else
                        printf("Top Element is %d",getTop(s));
                        break;
            case 4:
                    if(isStackEmpty(s))
                        printf("Stack is Empty.Can Not Print Entire Elements!");
                    else
                        DisplayStack(s);
                        break;
        }
    }
}


