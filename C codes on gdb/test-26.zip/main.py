divlist1=[]
mullist1=[]
mullist2=[]
n1=int(input())
n2=int(input())
for i in range(10):
    mullist1=n1*i
    mullist2=n2*i
    print(mull)