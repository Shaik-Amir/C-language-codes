#include<stdio.h>

int main()
{
      printf("dfgh");
  int n,i,a,j,k,l=0,dc=0;
 
  //scanf("%d",&a);
 a=10;
  for(k=0;k<a;k++)
  {
    if(n%k==0)
    dc++;
  }
  
    printf("%d..",dc);
}







int main()
{
  int n=0,i,j,k,l=0;
  scanf("%d",&n);
  int a[n],dc[n];
  for(i=0;i<n;i++)
  {
    scanf("%d",&a[i]);
  }
  for(j=0;j<n;j++)
  for(k=0;k<a[n];k++)
  {
    if(a[n]%k==0)
    dc[n]++;
  }
  printf("%d",dc[0]);
  return 0;
}
