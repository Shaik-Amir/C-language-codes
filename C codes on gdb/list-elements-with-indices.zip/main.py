nums=[55,53,56,42,86]
for i in enumerate(nums):
    print(i)
print("SUM IS",sum(nums))
print("MIN IS",min(nums))
print("MAX IS",max(nums))
