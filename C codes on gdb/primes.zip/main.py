p=int(input("prime numbers till: "))
count=0
primes=[]
for i in range(1,100,1):
    if p%i==0:
        count=count+1
        primes.append(i)
if count==2:
    print("s")
    print(primes)