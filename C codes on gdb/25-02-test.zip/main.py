number=int(input())
divlist=[]
for i in range (1,number+1):
    if number%i==0:
        divlist.append(i)
print("divisors are: ",divlist)
print("number of divisors are: ",len(divlist))
prilist=[]
for j in divlist:
    if j>1:
        for k in range(2,j):
            if j%k==0:
                break
        else:
            prilist.append(j)
print("prime numbers in divisors are",prilist)
print("sum of prime numbers: ",sum(prilist))
