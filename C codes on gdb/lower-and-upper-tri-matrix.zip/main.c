/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int r,c,i,j,b;
    printf("Input the matrix size: ");
    scanf("%d %d",&r,&c);
    int a[r][c];
    printf("input thr matrix elements: ");
    for (i=0;i<=r-1;i++)
    for (j=0;j<=c-1;j++)
    scanf("%d",&a[i][j]);
    
    for (i=0;i<=r-1;i++)
    {
    for (j=0;j<=c-1;j++)
    {
        if (i>j)
        a[i][j]=0;
        printf("%d   ",a[i][j]);
    }
    printf("\n");
    }
    /*
    for(i=0;i<=r;i++)
    {
        for (j=0;j<=c;j++)
        {
            if(j>i)
            a[i][j]=0;
            printf("%d    ",a[i][j]);
        }
    printf("\n");
    }
    */
    
    
    return 0;
}
