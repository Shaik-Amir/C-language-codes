/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,i,ecount=0,ocount=0;
    printf("input the array size: ");
    scanf("%d",&n);
    int a[n];
    printf("input the array elements: ");
    for (i=0;i<=n-1;i++)
    scanf("%d",&a[i]);
    for(i=0;i<=n-1;i++)
    {
        if (a[i]%2==0)
        ecount++;
        if(a[i]%2==1)
        ocount++;
    }
    if (ecount==ocount)
    printf("luncky array");
    else
    printf("unlucky");
    return 0;
}
