/*
Magical Subarray
A subarray is said to be 
m
a
g
i
c
a
l
 if the sum of the divisor's count of the elements in the subarray is odd.

Given an array of integers. Find the number of subarrays that are magical in a given array.

Example

If 
A
=
[
3
,
9
,
17
]
 . The number of magical subarrays is 4.

The divisor count of 
A
[
1
]
=
3
 is 
2
 because it has 
2
 divisors i.e. 
1
 and 
3
.
Similarly, the divisor count for 
9
 is 
3
, and 
17
 is 
2
.
4
 magical subarrays are 
[
9
]
, 
[
9
,
17
]
, 
[
3
,
9
]
, 
[
3
,
9
,
17
]
.

Input Format
The first line contains integer 
N
, denoting the number of elements in the array.
The next line contains 
N
 space-separated integers denoting the elements of an array.

Output Format:
A single integer which is the number of 
m
a
g
i
c
a
l
 subarrays.

Time Limit
1 second

Constraints
1
≤
N
≤
10
5

1
≤
A
[
i
]
≤
10
18

Sample Input
3
3 9 17

Sample Output
4

*/


#include<stdio.h>
#include<math.h>
int countDivisors(int n)
{
    int cnt = 0;
    for (int i = 1; i <= sqrt(n); i++) {
        if (n % i == 0) {
            if (n / i == i)
                cnt++;
            else 
                cnt = cnt + 2;
        }
    }
    return cnt;
}
// printf("%d",countDivisors(9));


int main()
{
   unsigned int n,i,j,k,l=0,odc=0,edc=0,nsa=0;
   scanf("%d",&n);
   unsigned int a[n],dc[n];
   for(i=0;i<n;i++)
   {
      scanf("%d",&a[i]);
   }
   for(i=0;i<n;i++)
   {
      //printf("%d ",a[i]);
   }
   //printf("\n");
   for(i=0;i<n;i++)
   {
      dc[i]=countDivisors(a[i]);
   }
   for(i=0;i<n;i++)
   {
      //printf("%d ",dc[i]);
   }
   for(i=0;i<n;i++)
   {
      if(dc[i]%2==0)
      edc++;
   }
   for(i=0;i<n;i++)
   {
      if(dc[i]%2==1)
      odc++;
   }
   //printf("\nodc=%d ,edc=%d",odc,edc);
   if(odc==0){
      printf("%d",0);
      return 0;}
   nsa=pow(2,edc)*pow(2,odc-1);
   printf("%d",nsa);
   return 0;
}
