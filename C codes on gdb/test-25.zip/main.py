number=int(input())
divlist=[]
for i in range (1,number+1):
    if number%i==0:
        divlist.append(i)
print("divisors are: ",divlist)
print("number of divisors are: ",len(divlist))
prilist=[]
for j in divlist:
    if j>1:
        for k in range(2,j):
            if j%k==0:
                break
        else:
            prilist.append(j)
print("prime numbers in divisors are",prilist)
summ=0
for x in range(len(prilist)):
    summ=summ+prilist[x]
print("sum of prime numbers: ",summ)
a=b=c=0

def length(b):
    for l in divlists:
        if b[l]==" ":
            c+=1
print(c)
    

