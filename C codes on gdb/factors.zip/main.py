n=int(input("factors of the number: "))
for i in range(1,n):
    if n%i==0:
        print(i)
        
p=int(input("prime numbers till: "))
count=0
for j in range(1,p):
    if p%j==0:
        count+=1
    if count==2:
        print(j)