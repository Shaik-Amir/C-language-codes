#include <stdio.h>
int flag1=0,fj,fk,min;
int notejk(int ,int);
int main()
{
   int t1,t,i,z;
   scanf("%d",&t1);
   if(t1>0&&t1<=100)
      t=t1;
   else
      return(0);
   int n[t];
   for(i=0;i<t;i++)
   {
      scanf("%d",&z);
      if(z>0)
      {
         n[i]=z;
      }
      else
      n[i]=1;
   }
   /*for(i=0;i<t;i++)
   {
      printf("%d ",n[i]);
   }*/
   int j=0,k=0;
   for(i=0;i<t;i++)
   {
   //i=0;
   min=n[i];
   for(j=0;j<=k+1;j++)
   {
      for(k=0;k<=n[i];k++)
      {
         if((j+k)==n[i])
         {
            /*if (flag1==1)
            {
               printf("\nj=%d,k=%d",fj,fk);
               return(0);
            }*/
            notejk(j,k);
            /*if(j<=k)
            {
               if(k-j<=min)
               {
                  min=k-j;
                  fj=j;
                  fk=k;
                  if (min==0)
                    break;
               }*/
            
         }
      }
   }
   printf("\n%d %d",fj,fk);
   }
    return 0;
}

int notejk(int j,int k)
{
   if(j<=k)
   {
      if(k-j<=min)
      {
         min=k-j;
         fj=j;
         fk=k;
         if(min==0)
         {
            fj=j;
            fk=k;
            flag1=1;
         }
      }
   }
}