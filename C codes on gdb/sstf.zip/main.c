#include<stdio.h>
#include<stdlib.h>
#include<math.h>
main(){
int dreq[20],tdreq[20],cpos,i,j,TAD=0,n,maxcylno,small,index,diff;
system("clear");
printf("\nEnter the number of disk reqs: ");
scanf("%d",&n);
printf("\nReading disk requests\n");
for(i=0;i<n;i++){
printf("\nEnter disk req[%d]:\t",i+1);
scanf("%d",&dreq[i]);
tdreq[i]=dreq[i];
}
printf("\nEnter current position of disk Read Write Head: \n");
scanf("%d",&cpos);
printf("\nEnter the maximum number of cylinders: \n");
scanf("%d",&maxcylno);
for(i=0;i<n;i++){
small=maxcylno;
index=0;
for(j=0;j<n;j++){
if(tdreq[j]!=-1){
diff=abs(tdreq[j]-cpos);
if(small>=diff){
small=diff;
index=j;
}
}
}
printf("%d - ",cpos);
TAD=TAD+abs(dreq[index]-cpos);
cpos=dreq[index];
tdreq[index]=-1;
}
printf(" %d\n",cpos);
printf("\nTotal Disk arm movement to serve all requests = %d\n",TAD);
}