/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,i,j,t;
    printf("input the array size: ");
    scanf("%d",&n);
    int a[n];
    printf("input the array elements: ");
    for (i=0;i<=n-1;i++)
    scanf("%d",&a[i]);
    for (i=0;i<=n-1;i++)
    for (j=i+1;j<=n-1;j++)
    {
        if (a[i]>a[j])
        {
            t=a[i];
            a[i]=a[j];
            a[j]=t;
        }
    }
    for(i=0;i<=n-1;i++)
    printf("%d",a[i]);
    return 0;
}
