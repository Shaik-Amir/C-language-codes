#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int largest(int arr[], int n)
{
    int i; 
    // Initialize maximum element
    int max = arr[0];
    // Traverse array elements
    // from second and compare
    // every element with current max
    for (i = 1; i < n; i++)
        if (arr[i] > max)
            max = arr[i];
    return max;
}


int main()
{
   unsigned int i=5,k=0,n,j,stepn=0;
   k=i%2;
   scanf("%d",&n);
   unsigned int a[n];
   for(i=0;i<n;i++)
      scanf("%d",&a[i]);
   while(stepn<=largest(a,n))
   {
      for(i=0;i<n;i++)
      {
         if(a[i]==stepn)
         {
            k=stepn%2;
            a[i]=stepn+pow(-1,k+1);
         }
      }
      for(i=0;i<n;i++)
         printf("%d ",a[i]);
      printf("\n");
      stepn++;
   }
      //printf("%d ",largest(a,n));
  /* for(i=0;i<n;i++)
      printf("%d ",a[i]);*/
  return 0;
}
